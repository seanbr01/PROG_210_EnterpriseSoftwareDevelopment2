﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeanBruce_HW_8
{
    public partial class Form1 : Form
    {
        BirdsEntities birdsEntities = new BirdsEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var birds = from birdCounts in birdsEntities.BirdCounts
                        from bird in birdsEntities.Birds
                        where birdCounts.BirdID == bird.BirdID
                        orderby birdCounts.Count ascending
                        select new
                        {
                            birdCounts.BirderID,
                            birdCounts.Count,
                            bird.Name
                        };

            dataGridView1.DataSource = birds.ToList();
        }
    }
}
