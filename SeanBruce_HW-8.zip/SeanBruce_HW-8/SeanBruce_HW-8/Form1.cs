﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeanBruce_HW_8
{
    public partial class Form1 : Form
    {
        BirdsEntities birdsEntities = new BirdsEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var birds = from birdCounts in birdsEntities.BirdCounts
                        join bird in birdsEntities.Birds
                        on birdCounts.BirdID equals bird.BirdID
                        join birder in birdsEntities.Birders
                        on birdCounts.BirderID equals birder.BirderID
                        orderby birdCounts.Count
                        select new
                        {
                            birder.BirderID,
                            birdCounts.Count,
                            bird.Name
                        };

            dataGridView1.DataSource = birds.ToList();
        }
    }
}
