﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeanBruce_FinalExam
{
    public class SportsAreUsEntity
    {
        public static SportsAreUsEntities entities = new SportsAreUsEntities();
    }
}
