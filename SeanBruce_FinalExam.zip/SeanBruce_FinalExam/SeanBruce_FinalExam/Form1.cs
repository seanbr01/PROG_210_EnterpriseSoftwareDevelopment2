﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SeanBruce_FinalExam
{
    public partial class Form1 : Form
    {
        public SportingItem sportingItem;
        public HealthItem healthItem;

        public Form1()
        {
            InitializeComponent();
            RefreshGrids();
        }

        public void RefreshGrids()
        {
            var sportGoods = from sportingItem in SportsAreUsEntity.entities.SportingItems
                             select sportingItem;
            dgvSportingGoods.DataSource = sportGoods.ToList();

            var healthProducts = from healthItem in SportsAreUsEntity.entities.HealthItems
                                 select healthItem;
            dgvHealthProducts.DataSource = healthProducts.ToList();
        }

        private void btnSportingToHealth_Click(object sender, EventArgs e)
        {
            healthItem = new HealthItem();

            int row = GetRowID(dgvSportingGoods, "SportingItemID");

            var selectedItem = (from item in SportsAreUsEntity.entities.SportingItems
                                where item.SportingItemID == row
                                select item).First();
            healthItem.HealthItemID = selectedItem.SportingItemID;
            healthItem.Name = selectedItem.Name;
            healthItem.Description = selectedItem.Description;
            healthItem.QuantityOnHand = selectedItem.QuantityOnHand;

            SportsAreUsEntity.entities.AddToHealthItems(healthItem);

            SportsAreUsEntity.entities.DeleteObject(selectedItem);

            SportsAreUsEntity.entities.SaveChanges();
            RefreshGrids();
        }

        private void btnHealthToSporting_Click(object sender, EventArgs e)
        {
            sportingItem = new SportingItem();

            int row = GetRowID(dgvHealthProducts, "HealthItemID");

            var selectedItem = (from item in SportsAreUsEntity.entities.HealthItems
                                where item.HealthItemID == row
                                select item).First();
            sportingItem.SportingItemID = selectedItem.HealthItemID;
            sportingItem.Name = selectedItem.Name;
            sportingItem.Description = selectedItem.Description;
            sportingItem.QuantityOnHand = selectedItem.QuantityOnHand;

            SportsAreUsEntity.entities.AddToSportingItems(sportingItem);

            SportsAreUsEntity.entities.DeleteObject(selectedItem);

            SportsAreUsEntity.entities.SaveChanges();
            RefreshGrids();
        }

        private int GetRowID(DataGridView dataGridView, string columnName)
        {
            var selected = dataGridView.CurrentRow;
            int countID = (int)selected.Cells[columnName].Value;

            return countID;
        }
    }
}
