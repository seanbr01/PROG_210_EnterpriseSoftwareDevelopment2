﻿namespace SeanBruce_FinalExam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSportingGoods = new System.Windows.Forms.DataGridView();
            this.dgvHealthProducts = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSportingToHealth = new System.Windows.Forms.Button();
            this.btnHealthToSporting = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSportingGoods)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHealthProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSportingGoods
            // 
            this.dgvSportingGoods.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvSportingGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSportingGoods.Location = new System.Drawing.Point(12, 12);
            this.dgvSportingGoods.Name = "dgvSportingGoods";
            this.dgvSportingGoods.RowTemplate.Height = 28;
            this.dgvSportingGoods.Size = new System.Drawing.Size(1059, 235);
            this.dgvSportingGoods.TabIndex = 0;
            // 
            // dgvHealthProducts
            // 
            this.dgvHealthProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvHealthProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHealthProducts.Location = new System.Drawing.Point(12, 299);
            this.dgvHealthProducts.Name = "dgvHealthProducts";
            this.dgvHealthProducts.RowTemplate.Height = 28;
            this.dgvHealthProducts.Size = new System.Drawing.Size(1059, 226);
            this.dgvHealthProducts.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(465, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sporting Goods";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(465, 528);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Health Products";
            // 
            // btnSportingToHealth
            // 
            this.btnSportingToHealth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSportingToHealth.Location = new System.Drawing.Point(39, 581);
            this.btnSportingToHealth.Name = "btnSportingToHealth";
            this.btnSportingToHealth.Size = new System.Drawing.Size(363, 33);
            this.btnSportingToHealth.TabIndex = 4;
            this.btnSportingToHealth.Text = "Move from Sporting to Health";
            this.btnSportingToHealth.UseVisualStyleBackColor = false;
            this.btnSportingToHealth.Click += new System.EventHandler(this.btnSportingToHealth_Click);
            // 
            // btnHealthToSporting
            // 
            this.btnHealthToSporting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnHealthToSporting.Location = new System.Drawing.Point(669, 585);
            this.btnHealthToSporting.Name = "btnHealthToSporting";
            this.btnHealthToSporting.Size = new System.Drawing.Size(363, 33);
            this.btnHealthToSporting.TabIndex = 5;
            this.btnHealthToSporting.Text = "Move from Health to Sporting";
            this.btnHealthToSporting.UseVisualStyleBackColor = false;
            this.btnHealthToSporting.Click += new System.EventHandler(this.btnHealthToSporting_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1083, 661);
            this.Controls.Add(this.btnHealthToSporting);
            this.Controls.Add(this.btnSportingToHealth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvHealthProducts);
            this.Controls.Add(this.dgvSportingGoods);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSportingGoods)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHealthProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSportingGoods;
        private System.Windows.Forms.DataGridView dgvHealthProducts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSportingToHealth;
        private System.Windows.Forms.Button btnHealthToSporting;
    }
}

