﻿namespace BirdsDataAdapter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewBirds = new System.Windows.Forms.DataGridView();
            this.dataGridViewEvents = new System.Windows.Forms.DataGridView();
            this.buttonMoveToTop = new System.Windows.Forms.Button();
            this.buttonMoveUpOne = new System.Windows.Forms.Button();
            this.buttonMoveDownOne = new System.Windows.Forms.Button();
            this.buttonMoveToBottom = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBirds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBirds
            // 
            this.dataGridViewBirds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBirds.Location = new System.Drawing.Point(90, 60);
            this.dataGridViewBirds.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewBirds.Name = "dataGridViewBirds";
            this.dataGridViewBirds.Size = new System.Drawing.Size(699, 368);
            this.dataGridViewBirds.TabIndex = 0;
            // 
            // dataGridViewEvents
            // 
            this.dataGridViewEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEvents.Location = new System.Drawing.Point(90, 566);
            this.dataGridViewEvents.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewEvents.Name = "dataGridViewEvents";
            this.dataGridViewEvents.Size = new System.Drawing.Size(699, 368);
            this.dataGridViewEvents.TabIndex = 1;
            // 
            // buttonMoveToTop
            // 
            this.buttonMoveToTop.Location = new System.Drawing.Point(858, 86);
            this.buttonMoveToTop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonMoveToTop.Name = "buttonMoveToTop";
            this.buttonMoveToTop.Size = new System.Drawing.Size(178, 35);
            this.buttonMoveToTop.TabIndex = 2;
            this.buttonMoveToTop.Text = "Move To Top";
            this.buttonMoveToTop.UseVisualStyleBackColor = true;
            this.buttonMoveToTop.Click += new System.EventHandler(this.buttonMoveToTop_Click);
            // 
            // buttonMoveUpOne
            // 
            this.buttonMoveUpOne.Location = new System.Drawing.Point(858, 182);
            this.buttonMoveUpOne.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonMoveUpOne.Name = "buttonMoveUpOne";
            this.buttonMoveUpOne.Size = new System.Drawing.Size(178, 35);
            this.buttonMoveUpOne.TabIndex = 3;
            this.buttonMoveUpOne.Text = "Move Up One";
            this.buttonMoveUpOne.UseVisualStyleBackColor = true;
            this.buttonMoveUpOne.Click += new System.EventHandler(this.buttonMoveUpOne_Click);
            // 
            // buttonMoveDownOne
            // 
            this.buttonMoveDownOne.Location = new System.Drawing.Point(858, 288);
            this.buttonMoveDownOne.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonMoveDownOne.Name = "buttonMoveDownOne";
            this.buttonMoveDownOne.Size = new System.Drawing.Size(178, 35);
            this.buttonMoveDownOne.TabIndex = 4;
            this.buttonMoveDownOne.Text = "Move Down One";
            this.buttonMoveDownOne.UseVisualStyleBackColor = true;
            this.buttonMoveDownOne.Click += new System.EventHandler(this.buttonMoveDownOne_Click);
            // 
            // buttonMoveToBottom
            // 
            this.buttonMoveToBottom.Location = new System.Drawing.Point(858, 392);
            this.buttonMoveToBottom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonMoveToBottom.Name = "buttonMoveToBottom";
            this.buttonMoveToBottom.Size = new System.Drawing.Size(178, 35);
            this.buttonMoveToBottom.TabIndex = 5;
            this.buttonMoveToBottom.Text = "Move To Bottom";
            this.buttonMoveToBottom.UseVisualStyleBackColor = true;
            this.buttonMoveToBottom.Click += new System.EventHandler(this.buttonMoveToBottom_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1161, 1032);
            this.Controls.Add(this.buttonMoveToBottom);
            this.Controls.Add(this.buttonMoveDownOne);
            this.Controls.Add(this.buttonMoveUpOne);
            this.Controls.Add(this.buttonMoveToTop);
            this.Controls.Add(this.dataGridViewEvents);
            this.Controls.Add(this.dataGridViewBirds);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = " I ca";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBirds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewBirds;
        private System.Windows.Forms.DataGridView dataGridViewEvents;
        private System.Windows.Forms.Button buttonMoveToTop;
        private System.Windows.Forms.Button buttonMoveUpOne;
        private System.Windows.Forms.Button buttonMoveDownOne;
        private System.Windows.Forms.Button buttonMoveToBottom;
    }
}

