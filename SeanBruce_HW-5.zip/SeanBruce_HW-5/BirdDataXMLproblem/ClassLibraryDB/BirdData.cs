﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDB
{
    public class BirdData
    {
        //private const string connectString = @"Data Source=A254J-T006006;Initial Catalog = Birds;Integrated Security=SSPI";
        //private const string connectString = @"Data Source=BRU\SEANBR01;Initial Catalog = Birds;Integrated Security=SSPI";
        private const string connectString = @"Data Source=A135818\SQLEXPRESS;Initial Catalog = Birds;Integrated Security=SSPI";
        private const string sqlErrorMessage = "Database operation failed.  Please contact your System Administrator.";

        public static DataSet GetBirdInfo()
        {
            try
            {
                SqlDataAdapter birdDataAdapter = new SqlDataAdapter();
                DataSet birdsDataSet = new DataSet();
                birdDataAdapter.SelectCommand = new SqlCommand();
                birdDataAdapter.SelectCommand.CommandText = "Select * from BirdCount order by CountID";
                birdDataAdapter.SelectCommand.Connection = new SqlConnection();
                birdDataAdapter.SelectCommand.Connection.ConnectionString = connectString;
                birdDataAdapter.Fill(birdsDataSet, "BirdInfo");

                return birdsDataSet;
            }
            catch (SqlException sqlEx)
            {
                throw new ApplicationException(sqlErrorMessage);
            }
        }

        public static int SaveBirdInfo(DataSet birdDataSet)
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();

            //INSERT Command  ----------------------------------------------------------------------------------------------------------
            sqlDataAdapter.InsertCommand                             = new SqlCommand();
            sqlDataAdapter.InsertCommand.Connection                  = new SqlConnection();
            sqlDataAdapter.InsertCommand.Connection.ConnectionString = connectString;
            sqlDataAdapter.InsertCommand.CommandText =
                    @"INSERT INTO BirdCount (RegionID, BirderID, BirdID, CountDate, Count) " +
                    @"VALUES (@RegionID, @BirderID, @BirdID, @CountDate, @Count)";

            sqlDataAdapter.InsertCommand.Parameters.Add("@RegionID", SqlDbType.Int);
            sqlDataAdapter.InsertCommand.Parameters["@RegionID"].SourceColumn = "RegionID";

            sqlDataAdapter.InsertCommand.Parameters.Add("@BirderID", SqlDbType.Int);
            sqlDataAdapter.InsertCommand.Parameters["@BirderID"].SourceColumn = "BirderID";

            sqlDataAdapter.InsertCommand.Parameters.Add("@BirdID", SqlDbType.Int);
            sqlDataAdapter.InsertCommand.Parameters["@BirdID"].SourceColumn = "BirdID";

            sqlDataAdapter.InsertCommand.Parameters.Add("@CountDate", SqlDbType.Date);
            sqlDataAdapter.InsertCommand.Parameters["@CountDate"].SourceColumn = "CountDate";

            sqlDataAdapter.InsertCommand.Parameters.Add("@Count", SqlDbType.Int);
            sqlDataAdapter.InsertCommand.Parameters["@Count"].SourceColumn = "Count";

            //UPDATE Command  ----------------------------------------------------------------------------------------------------------
            sqlDataAdapter.UpdateCommand                             = new SqlCommand();
            sqlDataAdapter.UpdateCommand.Connection                  = new SqlConnection();
            sqlDataAdapter.UpdateCommand.Connection.ConnectionString = connectString;
            sqlDataAdapter.UpdateCommand.CommandText =
                " UPDATE BirdCount SET RegionID = @RegionID, BirderID =@BirderID, BirdID= @BirdID, " +
                " CountDate=@CountDate, Count=@Count WHERE CountID = @CountID";

            //Set up the parameters for the update command  (need to change from productDataAdapter.InsertCommand.Parameters
            // to productDataAdapter.UpdateCommand.Parameters

            sqlDataAdapter.UpdateCommand.Parameters.Add("@CountID", SqlDbType.Int);
            sqlDataAdapter.UpdateCommand.Parameters["@CountID"].SourceColumn = "CountID";

            sqlDataAdapter.UpdateCommand.Parameters.Add("@RegionID", SqlDbType.Int);
            sqlDataAdapter.UpdateCommand.Parameters["@RegionID"].SourceColumn = "RegionID";

            sqlDataAdapter.UpdateCommand.Parameters.Add("@BirderID", SqlDbType.Int);
            sqlDataAdapter.UpdateCommand.Parameters["@BirderID"].SourceColumn = "BirderID";

            sqlDataAdapter.UpdateCommand.Parameters.Add("@BirdID", SqlDbType.Int);
            sqlDataAdapter.UpdateCommand.Parameters["@BirdID"].SourceColumn = "BirdID";

            sqlDataAdapter.UpdateCommand.Parameters.Add("@CountDate", SqlDbType.Date);
            sqlDataAdapter.UpdateCommand.Parameters["@CountDate"].SourceColumn = "CountDate";

            sqlDataAdapter.UpdateCommand.Parameters.Add("@Count", SqlDbType.Int);
            sqlDataAdapter.UpdateCommand.Parameters["@Count"].SourceColumn = "Count";

            sqlDataAdapter.UpdateCommand.Connection.Open();

            //Use the DataAdapter to update the database
            int rowCount = sqlDataAdapter.Update(birdDataSet, "BirdInfo");

            return rowCount;
        }
    }
}
