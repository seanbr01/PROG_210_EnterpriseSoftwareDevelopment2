﻿using ClassLibraryDB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BirdDataAdapterHW
{
    public partial class Form1 : Form
    {
        DataSet sqlBirdsDataSet;
        XMLdataSet myXMLDataSet;
        string xmlPath = $"{AppDomain.CurrentDomain.BaseDirectory}RemoteBirdClub.xml";

        public Form1()
        {
            InitializeComponent();
            myXMLDataSet = new XMLdataSet();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                BirdData.SaveBirdInfo(sqlBirdsDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            refresh();  // a call to the refresh method.
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            refresh();  // a call to the refresh method.
            myXMLDataSet.ReadXml(xmlPath);
        }

        private void refresh()
        {
            try
            {
                sqlBirdsDataSet              = BirdData.GetBirdInfo();
                DataGridViewBirds.DataSource = sqlBirdsDataSet;
                DataGridViewBirds.DataMember = "BirdInfo";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void buttonReadXML_Click(object sender, EventArgs e)
        {
            dataGridViewXML.DataSource = myXMLDataSet.Tables["BirdCount"];
        }

        private void buttonUpdateFromXML_Click(object sender, EventArgs e)
        {
            foreach (XMLdataSet.BirdCountRow oneXMLrow in myXMLDataSet.BirdCount)
            {
                DataRow dataRow      = sqlBirdsDataSet.Tables["BirdInfo"].NewRow();
                dataRow["RegionID"]  = oneXMLrow.RegionID;
                dataRow["BirderID"]  = oneXMLrow.BirderID;
                dataRow["BirdID"]    = oneXMLrow.BirdID;
                dataRow["CountDate"] = oneXMLrow.CountDate;
                dataRow["Count"]     = oneXMLrow.Count;

                sqlBirdsDataSet.Tables["BirdInfo"].Rows.Add(dataRow);
            }

            // But before you do that, you need to update the DataAdapter to enable it to do inserts.

            // Note, make sure your Region table, Bird table, and BirdID tables all have valid entries to 
            // match the values used in my XML file.  I used just 1's and 2's. If your tables don't have those
            // values, you can TRY to edit the XML file to set it to values that do match your tables.

        }
    }
}
