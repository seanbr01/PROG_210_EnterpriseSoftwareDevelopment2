﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InClass1stEF
{
    public partial class VendorRelationship : Form
    {
        PayablesEntities1 payables = new PayablesEntities1();
        public VendorRelationship()
        {
            InitializeComponent();
        }

        private void VendorRelationship_Load(object sender, EventArgs e)
        {
            DateTime payDate = new DateTime();
            payDate = DateTime.Now;

            var invoicesDue =
                from invoice in payables.Invoices
                let BalanceDue = invoice.InvoiceTotal - invoice.PaymentTotal - invoice.CreditTotal
                where BalanceDue > 0 && invoice.DueDate < payDate
                orderby invoice.Vendor.Name, BalanceDue descending  // invoice.Vendor.Name is going back to a single item, one vendor
                select new { invoice.Vendor.Name, Number = invoice.InvoiceNumber, BalanceDue };

            //This looks similar to the example in other form, but gets an error
            //var invoicesDue =
            //    from invoice in payables.Invoices  // note last time we did it in opposite order, from vendor, then from invoice
            //    from vendor in invoice.Vendor
            //    let BalanceDue = invoice.InvoiceTotal - invoice.PaymentTotal - invoice.CreditTotal
            //    where BalanceDue > 0 && invoice.DueDate < payDate
            //    orderby vendor.Name, BalanceDue descending
            //    select new { vendor.Name, Number = invoice.InvoiceNumber, BalanceDue };

            //An expression of type 'InvoiceDataModel.Vendor' is not allowed in a subsequent from clause in a query expression with source type
            // 'System.Data.Objects.ObjectSet<InvoiceDataModel.Invoice>'.  Type inference failed in the call to 'SelectMany'.
            // when it is a many to one, you must use the above stucture

            dataGridView1.DataSource = invoicesDue.ToList();


        }
    }
}
