﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InClass1stEF
{
    public partial class Form1 : Form
    {
        PayablesEntities1 payables = new PayablesEntities1();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //A query expression that retrieves invoices over $5000
            var highInvoices =
                 from invoice in payables.Invoices  // entity collection
                 where invoice.InvoiceTotal > 5000
                 orderby invoice.InvoiceTotal descending
                 select new
                 {
                     invoice.InvoiceNumber,
                     invoice.InvoiceTotal,
                     invoice.InvoiceDate
                 };

            // display results with ugly string building and a MessageBox
            string displayResult = "Invoice No.\tInvoice Total\n";
            foreach (var invoice in highInvoices)
            {
                displayResult += invoice.InvoiceNumber + "\t\t" +
                invoice.InvoiceTotal.ToString("c") + "\n";
            }

            MessageBox.Show(displayResult, "Invoices Over $500");


        }

        private void button2_Click(object sender, EventArgs e)
        {
            new SimpleDataGridView().Show();  // just open a new form
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Relationships().Show();  // just open a new form
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new VendorRelationship().Show();  // just open a new form
        }
    }
}
