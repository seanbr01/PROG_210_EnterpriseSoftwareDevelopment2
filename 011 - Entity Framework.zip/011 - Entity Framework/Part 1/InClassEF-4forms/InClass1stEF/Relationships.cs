﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InClass1stEF
{
    public partial class Relationships : Form
    {
        PayablesEntities1 payables = new PayablesEntities1();
        public Relationships()
        {
            InitializeComponent();
        }

        private void Relationships_Load(object sender, EventArgs e)
        {
            DateTime payDate = new DateTime();
            payDate = DateTime.Now;

            var invoicesDue =
                from vendor in payables.Vendors
                select new { vendor.Name, vendor.State };  // gets all the vendors

            //var invoicesDue =
            //    from vendor in payables.Vendors // gets all the vendors
            //    select new { vendor.Name, vendor.Invoices.Count };
            //still gets all the vendors  (note, Invoices.Count returns a single item)

            //var invoicesDue =
            // from vendor in payables.Vendors
            // from invoice in vendor.Invoices  // the from   from relationship creates a logical join
            // select new { vendor.Name };    // so now we get the Vendors repeated once for each invoice they have

            //var invoicesDue =
            //    from vendor in payables.Vendors
            //    from invoice in vendor.Invoices   // this is getting a one (Vendor) to Many (Invoice's)
            //    let BalanceDue = invoice.InvoiceTotal
            //    - invoice.PaymentTotal - invoice.CreditTotal
            //    where BalanceDue > 0 && invoice.DueDate < payDate
            //    orderby invoice.Vendor.Name, BalanceDue descending
            //    select new { vendor.Name, Number = invoice.InvoiceNumber, BalanceDue };
            // note renaming  invoice.InvoiceNumber to a human friendly name


            //var invoicesDue =
            //    from vendor in payables.Vendors
            //    select new { vendor.Name, vendor.Invoices.anyInvoiceField }; // refuses to  get a one to many 
            //without the from vendor and from invoice  logical join

            dataGridView1.DataSource = invoicesDue.ToList();
        }
    }
}
