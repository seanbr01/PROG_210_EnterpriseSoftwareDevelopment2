﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InClass1stEF
{
    public partial class SimpleDataGridView : Form
    {
        PayablesEntities1 payables = new PayablesEntities1();
        public SimpleDataGridView()
        {
            InitializeComponent();
        }

        private void SimpleDataGridView_Load(object sender, EventArgs e)
        {
            var highInvoices =
                from invoice in payables.Invoices
                where invoice.InvoiceTotal > 10
                orderby invoice.InvoiceTotal descending
                select new { invoice.InvoiceNumber,
                    invoice.InvoiceTotal,
                    invoice.InvoiceDate };

            dataGridView1.DataSource = highInvoices.ToList();

        }
    }
}
