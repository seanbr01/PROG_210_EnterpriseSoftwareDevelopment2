﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog210_1stDBAccess_WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // prepare and format the listView
            listView1.BackColor = System.Drawing.Color.LightBlue;  // just playing with the listview props and appearance
            listView1.ForeColor = System.Drawing.Color.Blue;
            listView1.BorderStyle = BorderStyle.Fixed3D;
            listView1.View = View.Details;
            listView1.Columns.Add("CompanyName", 200, HorizontalAlignment.Left);  // these numbers are pixels, not characters
            listView1.Columns.Add("Phone", 100, HorizontalAlignment.Left);
           
            listView1.GridLines = true;
       

             // our 3 ADO objects for reading data from Prog117:  SqlCommand  SqlDataReader  SqlConnection
            SqlCommand selectCommand;   //sql command object
            SqlDataReader sqlReader;   //datareader

            //Configure the command object
            
            // instantiate the command 
            selectCommand = new SqlCommand();

            // the Prog 117 way
            const string connectString = @"Server=localhost; Database=northwind; Integrated Security=True";
            SqlConnection conn;
            conn = new SqlConnection(connectString);
            selectCommand = new SqlCommand("Select CompanyName, Phone from Shippers", conn);


            ////set up the connection for the command
            //selectCommand.Connection = new SqlConnection(); // the Command object has a connection propertry
            //// we set the value of that property to be a object, a sqlconnection object.

            //// that sqlconnection object itself has a property, a connection string, we'll set it
            //const string connectString = @"Server=localhost\SqlExpress; Database= Northwind; Integrated Security=True";
            //// (the @ tells C# to ignore any funny characters, like the \ )
            //selectCommand.Connection.ConnectionString = connectString;

            //// the command object's connection object has a 2nd important propery, the CommandText
            //selectCommand.CommandText = "Select CompanyName, Phone from Shippers";
           
            //open the database connection
            selectCommand.Connection.Open();

            //execute sql against the database
            sqlReader = selectCommand.ExecuteReader();

            
            while (sqlReader.Read())
	        {
                listView1.Items.Add(sqlReader[0].ToString());
                listView1.Items[listView1.Items.Count - 1].SubItems.Add(sqlReader[1].ToString());
	        }
            
            sqlReader.Close();
            selectCommand.Connection.Close();
            
        }
        }
    }

