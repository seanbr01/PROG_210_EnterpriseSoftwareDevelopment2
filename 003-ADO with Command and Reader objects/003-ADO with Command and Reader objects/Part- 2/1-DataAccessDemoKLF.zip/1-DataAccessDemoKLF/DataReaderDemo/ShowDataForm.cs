using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataAccessLib;



namespace DataDemo
{
    public partial class ShowDataForm : Form
    {
        public ShowDataForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// This method shows the use of the datareader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fillButton_Click(object sender, EventArgs e)
        {  
            // Demo 1  -- call the Access Class with the empty country
            try
            {
                //set the cursor to the hour glass
                this.Cursor = Cursors.WaitCursor;
                customerComboBox.DataSource = NorthwindDataAccess.GetCustomers("");
              }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                //reset cursor
                this.Cursor = Cursors.Default;
            }
        }

        /// <summary>
        /// This method shows the use of the datareader and building SQL strings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fillCountryButton_Click(object sender, EventArgs e)
        {
            // Demo 2  -- call the Access Class with the country set
            try
            {
                //set the cursor to the hour glass
                this.Cursor = Cursors.WaitCursor;
                customer2ComboBox.DataSource = NorthwindDataAccess.GetCustomers(countryTextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                //reset cursor
                this.Cursor = Cursors.Default;
            }

        }

        private void ShowDataForm_Load(object sender, EventArgs e)
        {

        }
    }
}
