using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Collections;


namespace DataAccessLib
{
    public static class NorthwindDataAccess
    {
        //Note:  If your server is not named localhost, you will need to change the connection string
        //private const string connectString = @"Server = localhost;Database=Northwind;Integrated Security=SSPI";
        //private const string connectString = @"Server=A254J-T006006; Database= Northwind; Integrated Security=True";

        /// <summary>
        /// Retrieves list of customers from the Northwind210 database
        /// </summary>
        /// <param name="countryName">
        /// only customers from the specified country are retrieved if the string is not ""
        /// if the string is "" (zero length string) then all customers are retrieved
        /// </param>
        /// <returns>
        /// a list containing  customer names
        /// </returns>
        public static List<String> GetCustomers(string countryName)
        {
          
            SqlDataReader customerReader;  //datareader
            SqlCommand selectCommand = new SqlCommand();  // instantiate the command 
            List<String>  customerList = new List<String>();  // instantiate List to return

            try
            {
                //Configure the command object, and set up the connection for the command
                selectCommand.Connection = new SqlConnection(connectString);

                //set up sql for the command based on what the value of the passed in parameter was
                if (countryName == "")
                {
                    selectCommand.CommandText =
                        "Select CompanyName from Customers order by CompanyName";
                }
                else
                {
                    selectCommand.CommandText =
                        "Select CompanyName from Customers where Country = '" +
                        countryName +   "' order by CompanyName";
                }

                selectCommand.Connection.Open();  //open the database connection

                customerReader = selectCommand.ExecuteReader();  //execute sql against the database

                //use data reader to retrieve rows one at a time
                while (customerReader.Read())
                {
                    customerList.Add(customerReader["CompanyName"].ToString());
                }

                customerReader.Close();  //close the data reader

                return customerList;  //return the List

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                selectCommand.Connection.Close();  //close the database connection
            }

        }

        public static List<String> GetShippers()
        {
            List<string> ShipperList = new List<string>();

            string sql = "Select CompanyName from Shippers";

            SqlCommand selectCommand = new SqlCommand(sql, new SqlConnection(connectString));
            try
            {
                selectCommand.Connection.Open();
                SqlDataReader SQLShipperReader = selectCommand.ExecuteReader();
                //use data reader to retrieve rows one at a time
                while (SQLShipperReader.Read())
                {
                    ShipperList.Add(SQLShipperReader["CompanyName"].ToString());
                }

                SQLShipperReader.Close();  //close the data reader

                return ShipperList;  //return the List

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                selectCommand.Connection.Close();
            }
        }



        /// <summary>
        /// Counts the number of Shippers in the Shippers table
        /// Demonstrates the use of the ExecuteScalar method of the Command class
        /// </summary>
        /// <returns>
        /// number of rows in the Shippers table
        /// </returns>
        public static int CountShippers()
        {
            
            string sql = "Select count(*) from Shippers";

            SqlCommand selectCommand = new SqlCommand(sql, new SqlConnection(connectString));
            try
            {
                selectCommand.Connection.Open();
                return Convert.ToInt32(selectCommand.ExecuteScalar());  // ExecuteScaler <<< returns a single value
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                selectCommand.Connection.Close();
            }
        }


        /// <summary>
        /// Inserts a new row into the Shippers table
        /// </summary>
        /// <param name="companyName">
        /// name of shipping company
        /// </param>
        /// <param name="phone">
        /// phone number of shipping company
        /// </param>
        /// <returns>
        /// number of rows inserted
        /// </returns>
        public static int AddShipper(string companyName, string phone)
        {
            SqlCommand insertCommand;
            int rowsAffected;
            insertCommand = new SqlCommand();

            try
            {
                insertCommand.Connection = new SqlConnection();
                insertCommand.Connection.ConnectionString = connectString;

                insertCommand.CommandText = " INSERT INTO Shippers  (CompanyName, Phone ) " +
                    " VALUES('" + companyName + "', '" + phone + "')";

                insertCommand.Connection.Open();

                rowsAffected = insertCommand.ExecuteNonQuery();  // ExecuteNonQuery   << returns no data, but does return a value

                return rowsAffected;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                insertCommand.Connection.Close();
            }

        }

      
    }
}
