﻿using System;
using System.Data.SqlClient;
using System.Linq;

namespace HW_6_LINQ
{
    static public class DataLayer
    {
        internal static IQueryable GetBirdCounts()
        {
            try
            {
                BirdsDataClassesDataContext myDataContext = new BirdsDataClassesDataContext();

                var birds = from bird in myDataContext.Birds
                            join birdCount in myDataContext.BirdCounts
                            on bird.BirdID
                            equals birdCount.BirdID
                            orderby bird.BirdID
                            select new { bird.BirdID, bird.Name, birdCount.Count, birdCount.CountDate };

                return birds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
