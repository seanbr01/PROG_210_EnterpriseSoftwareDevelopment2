﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BirdsDataAdapter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataSet birdDataSet;

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void buttonMoveToTop_Click(object sender, EventArgs e)
        {
            this.BindingContext[birdDataSet, "BirdDataTable"].Position = 0;
        }

        private void buttonMoveUpOne_Click(object sender, EventArgs e)
        {
            this.BindingContext[birdDataSet, "BirdDataTable"].Position -= 1;
        }

        private void buttonMoveDownOne_Click(object sender, EventArgs e)
        {
            this.BindingContext[birdDataSet, "BirdDataTable"].Position += 1;
        }

        private void buttonMoveToBottom_Click(object sender, EventArgs e)
        {
            this.BindingContext[birdDataSet, "BirdDataTable"].Position = this.BindingContext[birdDataSet, "BirdDataTable"].Count - 1;
        }

        private void RefreshData_Click(object sender, EventArgs e)
        {
            UpdateDataGridView();
        }

        private void CommitChanges_Click(object sender, EventArgs e)
        {
            DBaccess.CommitBirdData(birdDataSet);
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                int pointer = BindingContext[birdDataSet, "birdDataTable"].Position;
                birdDataSet.Tables["birdDataTable"].Rows[pointer].Delete();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateDataGridView()
        {
            birdDataSet                   = DBaccess.GetAllData();
            dataGridViewBirds.DataSource  = birdDataSet;
            dataGridViewBirds.DataMember  = "BirdDataTable";

            dataGridViewEvents.DataSource = birdDataSet;
            dataGridViewEvents.DataMember = "BirdDataTable.UsefulRelation";
        }
    }
}
