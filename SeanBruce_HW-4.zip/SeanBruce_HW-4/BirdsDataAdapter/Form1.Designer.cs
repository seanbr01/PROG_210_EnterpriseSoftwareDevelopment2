﻿namespace BirdsDataAdapter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewBirds = new System.Windows.Forms.DataGridView();
            this.dataGridViewEvents = new System.Windows.Forms.DataGridView();
            this.buttonMoveToTop = new System.Windows.Forms.Button();
            this.buttonMoveUpOne = new System.Windows.Forms.Button();
            this.buttonMoveDownOne = new System.Windows.Forms.Button();
            this.buttonMoveToBottom = new System.Windows.Forms.Button();
            this.RefreshData = new System.Windows.Forms.Button();
            this.CommitChanges = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBirds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewBirds
            // 
            this.dataGridViewBirds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBirds.Location = new System.Drawing.Point(60, 39);
            this.dataGridViewBirds.Name = "dataGridViewBirds";
            this.dataGridViewBirds.Size = new System.Drawing.Size(466, 239);
            this.dataGridViewBirds.TabIndex = 0;
            // 
            // dataGridViewEvents
            // 
            this.dataGridViewEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEvents.Location = new System.Drawing.Point(60, 368);
            this.dataGridViewEvents.Name = "dataGridViewEvents";
            this.dataGridViewEvents.Size = new System.Drawing.Size(631, 239);
            this.dataGridViewEvents.TabIndex = 1;
            // 
            // buttonMoveToTop
            // 
            this.buttonMoveToTop.Location = new System.Drawing.Point(572, 56);
            this.buttonMoveToTop.Name = "buttonMoveToTop";
            this.buttonMoveToTop.Size = new System.Drawing.Size(119, 23);
            this.buttonMoveToTop.TabIndex = 2;
            this.buttonMoveToTop.Text = "Move To Top";
            this.buttonMoveToTop.UseVisualStyleBackColor = true;
            this.buttonMoveToTop.Click += new System.EventHandler(this.buttonMoveToTop_Click);
            // 
            // buttonMoveUpOne
            // 
            this.buttonMoveUpOne.Location = new System.Drawing.Point(572, 118);
            this.buttonMoveUpOne.Name = "buttonMoveUpOne";
            this.buttonMoveUpOne.Size = new System.Drawing.Size(119, 23);
            this.buttonMoveUpOne.TabIndex = 3;
            this.buttonMoveUpOne.Text = "Move Up One";
            this.buttonMoveUpOne.UseVisualStyleBackColor = true;
            this.buttonMoveUpOne.Click += new System.EventHandler(this.buttonMoveUpOne_Click);
            // 
            // buttonMoveDownOne
            // 
            this.buttonMoveDownOne.Location = new System.Drawing.Point(572, 187);
            this.buttonMoveDownOne.Name = "buttonMoveDownOne";
            this.buttonMoveDownOne.Size = new System.Drawing.Size(119, 23);
            this.buttonMoveDownOne.TabIndex = 4;
            this.buttonMoveDownOne.Text = "Move Down One";
            this.buttonMoveDownOne.UseVisualStyleBackColor = true;
            this.buttonMoveDownOne.Click += new System.EventHandler(this.buttonMoveDownOne_Click);
            // 
            // buttonMoveToBottom
            // 
            this.buttonMoveToBottom.Location = new System.Drawing.Point(572, 255);
            this.buttonMoveToBottom.Name = "buttonMoveToBottom";
            this.buttonMoveToBottom.Size = new System.Drawing.Size(119, 23);
            this.buttonMoveToBottom.TabIndex = 5;
            this.buttonMoveToBottom.Text = "Move To Bottom";
            this.buttonMoveToBottom.UseVisualStyleBackColor = true;
            this.buttonMoveToBottom.Click += new System.EventHandler(this.buttonMoveToBottom_Click);
            // 
            // RefreshData
            // 
            this.RefreshData.BackColor = System.Drawing.Color.PaleGreen;
            this.RefreshData.Location = new System.Drawing.Point(60, 314);
            this.RefreshData.Name = "RefreshData";
            this.RefreshData.Size = new System.Drawing.Size(231, 23);
            this.RefreshData.TabIndex = 6;
            this.RefreshData.Text = "Refresh Data from SQL";
            this.RefreshData.UseVisualStyleBackColor = false;
            this.RefreshData.Click += new System.EventHandler(this.RefreshData_Click);
            // 
            // CommitChanges
            // 
            this.CommitChanges.BackColor = System.Drawing.Color.MistyRose;
            this.CommitChanges.Location = new System.Drawing.Point(297, 314);
            this.CommitChanges.Name = "CommitChanges";
            this.CommitChanges.Size = new System.Drawing.Size(229, 23);
            this.CommitChanges.TabIndex = 7;
            this.CommitChanges.Text = "Commit Changes to Bird Table";
            this.CommitChanges.UseVisualStyleBackColor = false;
            this.CommitChanges.Click += new System.EventHandler(this.CommitChanges_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.Color.LemonChiffon;
            this.Delete.Location = new System.Drawing.Point(572, 314);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(119, 23);
            this.Delete.TabIndex = 8;
            this.Delete.Text = "Delete Row";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 671);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.CommitChanges);
            this.Controls.Add(this.RefreshData);
            this.Controls.Add(this.buttonMoveToBottom);
            this.Controls.Add(this.buttonMoveDownOne);
            this.Controls.Add(this.buttonMoveUpOne);
            this.Controls.Add(this.buttonMoveToTop);
            this.Controls.Add(this.dataGridViewEvents);
            this.Controls.Add(this.dataGridViewBirds);
            this.Name = "Form1";
            this.Text = " I ca";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBirds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewBirds;
        private System.Windows.Forms.DataGridView dataGridViewEvents;
        private System.Windows.Forms.Button buttonMoveToTop;
        private System.Windows.Forms.Button buttonMoveUpOne;
        private System.Windows.Forms.Button buttonMoveDownOne;
        private System.Windows.Forms.Button buttonMoveToBottom;
        private System.Windows.Forms.Button RefreshData;
        private System.Windows.Forms.Button CommitChanges;
        private System.Windows.Forms.Button Delete;
    }
}

