﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirdsDataAdapter
{
    static public class DBaccess
    {
        //Note:  you will need to change the connection string
        //const string connectString = @"Server = A254J-T006006;Database=Birds;Integrated Security=SSPI";
        const string connectString = @"Server=A135818\SQLEXPRESS;Database=Birds;Integrated Security=SSPI";
        //const string connectString = @"Server=BRU\SEANBR01;Database=Birds;Integrated Security=SSPI";

        // Generic error message for database issues
        private const string sqlErrorMessage = "Database operation failed.  Please contact your System Administrator";

        internal static DataSet GetAllData()
        {
            try
            {
                SqlDataAdapter birdsDataAdapter = new SqlDataAdapter();  //define and instantiate the DataAdapter
                DataSet birdDataSet             = new DataSet("Bird DataSet");
                birdsDataAdapter.SelectCommand  = new SqlCommand();  // instantiate the command 

                DataRelation birdDataRelation;

                // Now configure the command object

                //set up the connection for the command
                birdsDataAdapter.SelectCommand.Connection                  = new SqlConnection();
                birdsDataAdapter.SelectCommand.Connection.ConnectionString = connectString;

                //set up sql for the command 
                birdsDataAdapter.SelectCommand.CommandText = "SELECT * FROM Bird ORDER BY BirdID";

                //use the DataAdapter to contact the database,  note that the Fill method will open & close the connection
                // for you as well as sending the SQL to the database
                birdsDataAdapter.Fill(birdDataSet, "birdDataTable");

                birdsDataAdapter.SelectCommand.CommandText = "SELECT * FROM BirdCount ORDER BY BirdID";
                birdsDataAdapter.Fill(birdDataSet, "birdCountDataTable");

                birdDataRelation = new DataRelation("UsefulRelation",
                    birdDataSet.Tables["birdDataTable"].Columns["BirdID"],
                    birdDataSet.Tables["birdCountDataTable"].Columns["BirdID"]);
                birdDataSet.Relations.Add(birdDataRelation);

                //return the DataTable
                return birdDataSet;
            }
            catch (SqlException sqlEx)  // catch SQL issues here
            {
                throw new ApplicationException(sqlErrorMessage);
            }
            catch (Exception ex)  // catch any other problems here
            {
                throw ex;
            }
        }

        public static int CommitBirdData(DataSet birdDataSet)
        {
            int rowCount;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();

            SqlParameter sqlParameter;

            try
            {
                //INSERT Command  ----------------------------------------------------------------------------------------------------------
                sqlDataAdapter.InsertCommand             = new SqlCommand();
                sqlDataAdapter.InsertCommand.CommandText = 
                    @"INSERT INTO Bird ( Name ) " + 
                    @"VALUES (@Name)";

                sqlDataAdapter.InsertCommand.Connection                  = new SqlConnection();
                sqlDataAdapter.InsertCommand.Connection.ConnectionString = connectString;

                sqlDataAdapter.InsertCommand.Parameters.Add("@Name", SqlDbType.NVarChar, 50);
                sqlDataAdapter.InsertCommand.Parameters["@Name"].SourceColumn = "Name";

                //UPDATE Command  ----------------------------------------------------------------------------------------------------------

                sqlDataAdapter.UpdateCommand                             = new SqlCommand();
                sqlDataAdapter.UpdateCommand.Connection                  = new SqlConnection();
                sqlDataAdapter.UpdateCommand.Connection.ConnectionString = connectString;
                sqlDataAdapter.UpdateCommand.Connection                  = sqlDataAdapter.UpdateCommand.Connection;

                sqlDataAdapter.UpdateCommand.CommandText =
                    @"UPDATE Bird SET Name = @Name " + 
                    @"WHERE BirdID         = @BirdID";

                sqlDataAdapter.UpdateCommand.Parameters.Add("@BirdID", SqlDbType.Int);
                sqlDataAdapter.UpdateCommand.Parameters["@BirdID"].SourceColumn = "BirdID";

                sqlDataAdapter.UpdateCommand.Parameters.Add("@Name", SqlDbType.NVarChar, 50);
                sqlDataAdapter.UpdateCommand.Parameters["@Name"].SourceColumn   = "Name";

                //DELETE Command  ----------------------------------------------------------------------------------------------------------

                sqlDataAdapter.DeleteCommand             = new SqlCommand();
                sqlDataAdapter.DeleteCommand.Connection  = sqlDataAdapter.InsertCommand.Connection;
                sqlDataAdapter.DeleteCommand.CommandText = @"DELETE FROM Bird WHERE BirdID = @BirdID;";

                sqlParameter               = new SqlParameter();
                sqlParameter.ParameterName = "@BirdID";
                sqlParameter.SourceColumn  = "BirdID";
                sqlDataAdapter.DeleteCommand.Parameters.Add(sqlParameter);

                sqlDataAdapter.UpdateCommand.Connection.Open();

                rowCount = sqlDataAdapter.Update(birdDataSet, "birdDataTable");

                return rowCount;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlDataAdapter.UpdateCommand.Connection.Close();
            }
        }
    }
}
