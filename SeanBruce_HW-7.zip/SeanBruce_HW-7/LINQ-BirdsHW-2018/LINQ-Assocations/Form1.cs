﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_Assocations
{
    public partial class Form1 : Form
    {
        //Get dataContext
        DataClassesBirdsDataContext myBirdData = new DataClassesBirdsDataContext();
        Prod_Cat_DataClassDataContext dataContext = new Prod_Cat_DataClassDataContext();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Style dataGridView
            dataGridViewBirds.AlternatingRowsDefaultCellStyle.BackColor = Color.PeachPuff;
            dataGridViewBirds.RowsDefaultCellStyle.BackColor            = Color.PowderBlue;
            dataGridViewBirds.AutoResizeColumns();

            //Style form
            this.BackColor = Color.AntiqueWhite;
        }

        private void refreshDataGridView()
        {
            var products = from productItem in dataContext.Products
                           join category in dataContext.Categories
                           on productItem.CategoryID
                           equals category.CategoryID
                           where productItem.UnitPrice > 40
                           orderby productItem.ProductName
                           select new
                           {
                               category.CategoryName,
                               category.Description,
                               productItem.ProductName,
                               productItem.UnitPrice,
                               productItem.ProductID
                           };
            
            dataGridViewBirds.DataSource = products;
        }
        
        private void buttonGetBirds_Click(object sender, EventArgs e)
        {
            refreshDataGridView();
        }

        private void buttonUpdateCount_Click(object sender, EventArgs e)
        {
            int counted;

            if (Int32.TryParse(textBoxNewCount.Text, out counted))
            {
                var selected = dataGridViewBirds.CurrentRow;
                int countID = (int)selected.Cells["ProductID"].Value;

                var selectedProduct =
                    (from product in dataContext.Products
                     where product.ProductID == countID
                     select product).Single();
                selectedProduct.UnitPrice = counted;
                dataContext.SubmitChanges();
                refreshDataGridView();
            }
            else
            {
                MessageBox.Show("Please enter an integer number.");
            }
            textBoxNewCount.Text = string.Empty;
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //Retrieve selected row and id
            var selectedRow = dataGridViewBirds.CurrentRow;
            int selectedID = (int)selectedRow.Cells["CountID"].Value;

            //Retrieve row to delete from dataContext
            var rowToDelete =
                (from bird in myBirdData.BirdCounts
                 where bird.CountID == selectedID
                 select bird).Single();

            //Mark for deletion
            myBirdData.BirdCounts.DeleteOnSubmit(rowToDelete);

            //Try to submit changes
            try
            {
                myBirdData.SubmitChanges();  // LINQ to SQL does all the work for us
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting item: " + ex.Message);
            }

            //refresh gridView
            refreshDataGridView();
        }
    }
}
