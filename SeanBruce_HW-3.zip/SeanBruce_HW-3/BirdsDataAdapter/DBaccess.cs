﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirdsDataAdapter
{
    static public class DBaccess
    {
        //Note:  you will need to change the connection string
        //const string connectString = @"Server = A254J-T006006;Database=Birds;Integrated Security=SSPI";
        const string connectString = @"Server=A135818\SQLEXPRESS;Database=Birds;Integrated Security=SSPI";

        // Generic error message for database issues
        private const string sqlErrorMessage = "Database operation failed.  Please contact your System Administrator";

        internal static DataSet GetAllData()
        {
            try
            {
                SqlDataAdapter birdsDataAdapter = new SqlDataAdapter();  //define and instantiate the DataAdapter
                DataSet birdDataSet = new DataSet("Bird DataSet");
                birdsDataAdapter.SelectCommand = new SqlCommand();  // instantiate the command 

                DataRelation birdDataRelation;

                // Now configure the command object

                //set up the connection for the command
                birdsDataAdapter.SelectCommand.Connection = new SqlConnection();
                birdsDataAdapter.SelectCommand.Connection.ConnectionString = connectString;

                //set up sql for the command 
                birdsDataAdapter.SelectCommand.CommandText = "SELECT * FROM Bird ORDER BY Name";

                //use the DataAdapter to contact the database,  note that the Fill method will open & close the connection
                // for you as well as sending the SQL to the database
                birdsDataAdapter.Fill(birdDataSet, "birdDataTable");

                birdsDataAdapter.SelectCommand.CommandText = "SELECT * FROM BirdCount ORDER BY BirdID";
                birdsDataAdapter.Fill(birdDataSet, "birdCountDataTable");

                birdDataRelation = new DataRelation("UsefulRelation",
                    birdDataSet.Tables["birdDataTable"].Columns["BirdID"],
                    birdDataSet.Tables["birdCountDataTable"].Columns["BirdID"]);
                birdDataSet.Relations.Add(birdDataRelation);

                //return the DataTable
                return birdDataSet;
            }
            catch (SqlException sqlEx)  // catch SQL issues here
            {
                throw new ApplicationException(sqlErrorMessage);
            }
            catch (Exception ex)  // catch any other problems here
            {
                throw ex;
            }
        }
    }
}
