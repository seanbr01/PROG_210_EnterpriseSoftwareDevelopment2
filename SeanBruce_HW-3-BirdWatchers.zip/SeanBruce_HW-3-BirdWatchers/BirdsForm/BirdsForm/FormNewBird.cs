﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace BirdsForm
{
    public partial class FormNewBird : Form
    {
        BirdsFormVM birdsFormVM;
        public FormNewBird()
        {
            InitializeComponent();
            birdsFormVM = new BirdsFormVM();
        }

        private void buttonNewBird_Click(object sender, EventArgs e)
        {
            labelStatus.Text = birdsFormVM.AddBird(textBoxBird.Text);
        }
    }
}
