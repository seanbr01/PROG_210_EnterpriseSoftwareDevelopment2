﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using ClassLibrary1;

namespace BirdsForm
{
    public partial class FormNewBirder : Form
    {
        BirdsFormVM birdsFormVM;
        public FormNewBirder()
        {
            InitializeComponent();
            birdsFormVM = new BirdsFormVM();
        }

        private void buttonNewBirder_Click(object sender, EventArgs e)
        {
            if (textBoxFirstName.Text != string.Empty && textBoxLastName.Text != string.Empty && textBoxPhone.Text != string.Empty)
            {
                Birder birder = new Birder { FirstName = textBoxFirstName.Text, LastName = textBoxLastName.Text, PhoneNumber = textBoxPhone.Text };
                labelStatus.Text = birdsFormVM.AddBirder(birder);

                resetForm();
            }
            else
            {
                MessageBox.Show("Please fill all fields.");
            }
        }

        private void resetForm()
        {
            textBoxFirstName.Text = string.Empty;
            textBoxLastName.Text = string.Empty;
            textBoxPhone.Text = string.Empty;
        }
    }
}
