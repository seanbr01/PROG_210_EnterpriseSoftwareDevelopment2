﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace BirdsForm
{
    public partial class FormNewRegion : Form
    {
        BirdsFormVM birdsFormVM;
        public FormNewRegion()
        {
            InitializeComponent();
            birdsFormVM = new BirdsFormVM();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBoxRegion.Text != string.Empty)
            {
                labelStatus.Text = birdsFormVM.AddRegion(textBoxRegion.Text);
                textBoxRegion.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Please fill all fields.");
            }
        }
    }
}
