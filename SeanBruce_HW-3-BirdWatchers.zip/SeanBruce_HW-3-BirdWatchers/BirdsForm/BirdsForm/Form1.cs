﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace BirdsForm
{
    public partial class Form1 : Form
    {
        BirdsFormVM birdsFormVM;
        public Form1()
        {
            InitializeComponent();
            birdsFormVM = new BirdsFormVM();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            updateScreen();
        }

        private void updateScreen()
        {
            birdsFormVM.PopulateRegions(listBoxRegions);
            birdsFormVM.PopulateBirds(listBoxBirds);
            birdsFormVM.PopulateBirders(listBoxBirders);
            birdsFormVM.PopulateCountData(dataGridView1);
        }

        private void buttonAddEvent_Click(object sender, EventArgs e)
        {
            CountRow addCountRow = new CountRow
            {
                RegionID = Convert.ToInt32(listBoxRegions.SelectedValue),
                BirderID = Convert.ToInt32(listBoxBirders.SelectedValue),
                BirdID = Convert.ToInt32(listBoxBirds.SelectedValue),
                Count = Convert.ToInt32(textBoxCount.Text),
                CountDate = Convert.ToDateTime(textBoxDate.Text)
            };
            DBaccess.AddCount(addCountRow);

            updateScreen();  // refresh the display
        }

        private void buttonAddRegion_Click(object sender, EventArgs e)
        {
            new FormNewRegion().ShowDialog();  // opens and starts another form
            updateScreen();
        }

        private void buttonAddBirdType_Click(object sender, EventArgs e)
        {
            new FormNewBird().ShowDialog(); // opens and starts another form
            updateScreen();
        }

        private void buttonAddBirder_Click(object sender, EventArgs e)
        {
            new FormNewBirder().ShowDialog(); // opens and starts another form
            updateScreen();
        }
    }
}
