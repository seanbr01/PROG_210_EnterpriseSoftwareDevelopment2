﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using System.Windows.Forms;

namespace BusinessLayer
{
    public class BirdsFormVM
    {
        public void PopulateRegions(ListBox listBox)
        {
            listBox.DataSource = DBaccess.GetRegions();
        }

        public void PopulateBirds(ListBox listBox)
        {
            listBox.DataSource = DBaccess.GetBirds();
        }

        public void PopulateBirders(ListBox listBox)
        {
            listBox.DataSource = DBaccess.GetBirders();
        }

        public void PopulateCountData(DataGridView dataGridView)
        {
            dataGridView.DataSource = DBaccess.GetCountData();
        }

        public string AddBird(string birdName)
        {
            return DBaccess.InsertBird(birdName);
        }

        public string AddBirder(Birder birder)
        {
            return DBaccess.InsertBirder(birder);
        }

        public string AddRegion(string region)
        {
            return DBaccess.InsertRegion(region);
        }
    }
}
