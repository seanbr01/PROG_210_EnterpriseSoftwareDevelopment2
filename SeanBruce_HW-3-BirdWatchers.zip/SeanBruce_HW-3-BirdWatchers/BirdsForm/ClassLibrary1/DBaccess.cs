﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public static class DBaccess
    {
        //private const string connectString = @"Server=N252-000\MSSQLSERVER3; Database= Birds; Integrated Security=True";
        //private const string connectString = @"Server=A254J-t006006; Database= Birds; Integrated Security=True";
        private const string connectString = @"Server=BRU\SEANBR01; Database= Birds; Integrated Security=True";
        
        static public List<CountRow> GetCountData()
        {
            List<CountRow> DataList = new List<CountRow>();
            SqlDataReader birdReader;  //datareader
            SqlCommand selectCommand = new SqlCommand();
            selectCommand.Connection = new SqlConnection(connectString);
            selectCommand.CommandText =
                        "Select * from BirdCount order by BirdID";
            selectCommand.Connection.Open();

            birdReader = selectCommand.ExecuteReader();  //execute sql against the database

            //use data reader to retrieve rows one at a time
            while (birdReader.Read())
            {
                CountRow tempRow = new CountRow();
                tempRow.BirderID = (int)birdReader["BirderID"];
                tempRow.BirdID = (int)birdReader["BirdID"];
                tempRow.RegionID = (int)birdReader["RegionID"];
                tempRow.Count = (int)birdReader["Count"];
                tempRow.CountDate = (DateTime)birdReader["CountDate"];
                DataList.Add(tempRow);
            }

            birdReader.Close();  //close the data reader
            return DataList;
        }

        public static string InsertBird(string pNewBird)  // adds one new type of bird to the Bird table
        {
            string returnString = "failed to add new bird";
            try
            {
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = new SqlConnection(connectString);
                insertCommand.CommandText = "INSERT INTO Bird (Name) VALUES( @Name) ";
                // define the 1 Parameter since we cannot trust the textbox data
                insertCommand.Parameters.Add("@Name", System.Data.SqlDbType.NVarChar);
                insertCommand.Parameters["@Name"].Value = pNewBird;

                insertCommand.Connection.Open();
                insertCommand.ExecuteNonQuery();
                insertCommand.Connection.Close();
                returnString = "success, " + pNewBird + " added.";  // if we got this far, must have been successful.
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birds DB: " + ex);
            }
           
            return returnString;
            
        }

        public static string InsertRegion(string newRegion)
        {
            string returnString = "failed to add new region";
            try
            {
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = new SqlConnection(connectString);
                insertCommand.CommandText = "INSERT INTO Region (Name) VALUES( @Name) ";
                
                insertCommand.Parameters.Add("@Name", System.Data.SqlDbType.NVarChar);
                insertCommand.Parameters["@Name"].Value = newRegion;

                insertCommand.Connection.Open();
                insertCommand.ExecuteNonQuery();
                insertCommand.Connection.Close();
                returnString = "success, " + newRegion + " added.";
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Regions DB: " + ex);
            }

            return returnString;
        }

        public static string InsertBirder(Birder birder)
        {
            string returnString = "failed to add new birder";
            try
            {
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = new SqlConnection(connectString);
                insertCommand.CommandText = "INSERT INTO Birder (FirstName, LastName, PhoneNumber)" +
                    " VALUES( @FirstName, @LastName, @PhoneNumber) ";

                insertCommand.Parameters.Add("@FirstName", System.Data.SqlDbType.NVarChar);
                insertCommand.Parameters["@FirstName"].Value = birder.FirstName;
                insertCommand.Parameters.Add("@LastName", System.Data.SqlDbType.NVarChar);
                insertCommand.Parameters["@LastName"].Value = birder.LastName;
                insertCommand.Parameters.Add("@PhoneNumber", System.Data.SqlDbType.NVarChar);
                insertCommand.Parameters["@PhoneNumber"].Value = birder.PhoneNumber;

                insertCommand.Connection.Open();
                insertCommand.ExecuteNonQuery();
                insertCommand.Connection.Close();
                returnString = $"success, {birder.FirstName} {birder.LastName} added.";
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birders DB: " + ex);
            }

            return returnString;
        }

        public static void AddCount(CountRow addCountRow)  // add a row of data to the BirdCount table
        {
            try
            {
                SqlCommand insertCommand = new SqlCommand();
                insertCommand.Connection = new SqlConnection(connectString);
                insertCommand.CommandText =
                    "INSERT INTO BirdCount (BirderID, BirdID, RegionID, Count, CountDate ) VALUES( " + addCountRow.BirderID + "," + addCountRow.BirdID + "," + addCountRow.RegionID + " ,  @Count, @CountDate) ";
                // define the 2 Parameters since we cannot trust the textbox data
                insertCommand.Parameters.Add("@Count", System.Data.SqlDbType.Int);
                insertCommand.Parameters["@Count"].Value = addCountRow.Count;

                insertCommand.Parameters.Add("@CountDate", System.Data.SqlDbType.Date);
                insertCommand.Parameters["@CountDate"].Value = addCountRow.CountDate;

                insertCommand.Connection.Open();
                insertCommand.ExecuteNonQuery();
                insertCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birds DB: " + ex);
            }

        }

        // this code gets the Region names and IDs for the ListBox.  You will need two more methods like this for the other 2 new ListBoxes that you add.
        public static List<Regions> GetRegions()  // create a list of Region objects, one for each row of data in the Regions table
        {
            SqlConnection connection = new SqlConnection(connectString);
            SqlCommand commRegion = new SqlCommand("SELECT RegionID, Name FROM Region", connection);
            List<Regions> RegionList = new List<Regions>();
            try
            {
                connection.Open();
                SqlDataReader reader = commRegion.ExecuteReader();
                while (reader.Read())
                {
                    Regions tempRegion = new Regions();
                    tempRegion.RegionID = (int)reader["RegionID"];
                    tempRegion.Name = reader["Name"].ToString();
                    RegionList.Add(tempRegion);   // add the new object to the List
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birds DB: " + ex);
            }
            finally
            {
                connection.Close();
            }
            return RegionList;
        }

        public static List<Bird> GetBirds()
        {
            SqlConnection connection = new SqlConnection(connectString);
            SqlCommand commRegion = new SqlCommand("SELECT BirdID, Name FROM Bird", connection);
            List<Bird> BirdList = new List<Bird>();
            try
            {
                connection.Open();
                SqlDataReader reader = commRegion.ExecuteReader();
                while (reader.Read())
                {
                    Bird tempRegion = new Bird();
                    tempRegion.BirdID = (int)reader["BirdID"];
                    tempRegion.Name = reader["Name"].ToString();
                    BirdList.Add(tempRegion);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birds DB: " + ex);
            }
            finally
            {
                connection.Close();
            }
            return BirdList;
        }

        public static List<Birder> GetBirders()
        {
            SqlConnection connection = new SqlConnection(connectString);
            SqlCommand commRegion = new SqlCommand("SELECT BirderID, FirstName, LastName FROM Birder", connection);
            List<Birder> BirderList = new List<Birder>();
            try
            {
                connection.Open();
                SqlDataReader reader = commRegion.ExecuteReader();
                while (reader.Read())
                {
                    Birder tempRegion = new Birder();
                    tempRegion.BirderID = (int)reader["BirderID"];
                    tempRegion.FirstName = reader["FirstName"].ToString();
                    tempRegion.LastName = reader["LastName"].ToString();
                    BirderList.Add(tempRegion);
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                throw new ApplicationException("Error loading the from Birds DB: " + ex);
            }
            finally
            {
                connection.Close();
            }
            return BirderList;
        }
    }
}