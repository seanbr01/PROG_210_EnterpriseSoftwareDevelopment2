﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Birder
    {
        private int birderID;

        public int BirderID
        {
            get { return birderID; }
            set { birderID = value; }
        }

        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        private string phoneNumber;

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }

        private string fullName;
        public string FullName
        {
            get
            {
                return LastName + ", " + FirstName;
            }
            set { fullName = value; }
        }
    }
}
