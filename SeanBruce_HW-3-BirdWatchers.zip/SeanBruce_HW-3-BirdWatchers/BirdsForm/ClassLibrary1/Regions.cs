﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Regions
    {
        public int RegionID { get; set; }
        public string Name { get; set; }
    }
}
