﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class CountRow
    {
        public int RegionID { get; set; }
        public int BirdID { get; set; }
        public int BirderID { get; set; }
        public int Count { get; set; }
        public DateTime CountDate { get; set; }
    }
}
