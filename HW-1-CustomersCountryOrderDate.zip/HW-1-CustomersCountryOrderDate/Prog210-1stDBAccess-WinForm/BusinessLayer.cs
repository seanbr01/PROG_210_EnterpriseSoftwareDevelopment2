﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog210_1stDBAccess_WinForm
{
    public class BusinessLayer
    {
        DataLayer dataLayer;
        public BusinessLayer()
        {
            //const string SERVERNAME = @"A135818\SQLEXPRESS";
            const string SERVERNAME = @"BRU\SEANBR01";

            dataLayer = new DataLayer(SERVERNAME);
        }

        public void PopulateListVeiw(ListView listView)
        {
            dataLayer.GetCompanyCountryOrderDate(listView);
        }
    }
}
