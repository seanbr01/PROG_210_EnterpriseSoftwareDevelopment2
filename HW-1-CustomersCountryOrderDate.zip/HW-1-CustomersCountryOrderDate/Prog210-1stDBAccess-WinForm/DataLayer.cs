﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog210_1stDBAccess_WinForm
{
    public class DataLayer
    {
        private string serverName;

        public string ServerName
        {
            get { return serverName; }
            set { serverName = value; }
        }

        public DataLayer(string serverName)
        {
            this.serverName = serverName;
        }

        public void GetCompanyCountryOrderDate(ListView listView)
        {
            string connectionString = @"Server=" + ServerName + "; Database=northwind; Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            string command = "SELECT Customers.CompanyName, Customers.Country, Orders.OrderDate "
                + "FROM Customers INNER JOIN "
                + "Orders ON Customers.CustomerID = Orders.CustomerID "
                + @"WHERE Customers.Country = 'USA'";

            SqlCommand selectCommand = new SqlCommand(command, conn);
            selectCommand.Connection.Open();

            SqlDataReader sqlReader = selectCommand.ExecuteReader();

            while (sqlReader.Read())
            {
                listView.Items.Add(sqlReader[0].ToString());
                listView.Items[listView.Items.Count - 1].SubItems.Add(sqlReader[1].ToString());
                listView.Items[listView.Items.Count - 1].SubItems.Add(sqlReader[2].ToString());
            }

            sqlReader.Close();
            selectCommand.Connection.Close();
        }
    }
}
