﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog210_1stDBAccess_WinForm
{
    public partial class Form1 : Form
    {
        BusinessLayer businessLayer;
        public Form1()
        {
            InitializeComponent();
            businessLayer = new BusinessLayer();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            businessLayer.PopulateListVeiw(listView1);
        }
    }
}

