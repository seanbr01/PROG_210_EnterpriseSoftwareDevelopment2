﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeanBruce_HW_8
{
    public partial class Form1 : Form
    {
        BirdsEntities birdsEntities = new BirdsEntities();
        BirdsEntities1 birdsEntities1 = new BirdsEntities1();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            refreshDataGridView();
        }

        private void refreshDataGridView()
        {
            var birds = from birdCounts in birdsEntities.BirdCounts
                        orderby birdCounts.Count ascending
                        select new
                        {
                            birdCounts.CountID,
                            birdCounts.BirderID,
                            birdCounts.Count,
                            birdCounts.Bird.Name
                        };

            dataGridView1.DataSource = birds.ToList();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int counted;

            if (Int32.TryParse(txbNewCount.Text, out counted))
            {
                var selected = dataGridView1.CurrentRow;
                int countID = (int)selected.Cells["CountID"].Value;

                var selectedCount =
                    (from count in birdsEntities.BirdCounts
                     where count.CountID == countID
                     select count).Single();
                selectedCount.Count = counted;
                birdsEntities.SaveChanges();

                refreshDataGridView();
            }
            else
            {
                MessageBox.Show("Please enter an integer number.");
            }
            txbNewCount.Text = string.Empty;
        }
    }
}
